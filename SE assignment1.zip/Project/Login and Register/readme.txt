	Register and Login

This is a register and login functionality of any web based application.
It used the model-view-controller(MVC) architectural pattern.
	The view refers to the user interface, the public folder which includes the index.html in this case.
	The controller referes to the router which takes what the user entered and register a user, check if the user name specified by the user is not duplicated.And from the enterd ceredentail check if the username exists in the user data and compare the password for the login.
	The model referes to the data storage/database part of the app.In this module the database in the user.json file which is used to store the username and password of any registered user.



*To run the applicaltion
	- run the app.js in the command prompt
	- open localhost:3000 on the browser
