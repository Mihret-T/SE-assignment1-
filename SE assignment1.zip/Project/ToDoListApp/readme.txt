
			TO DO LIST APP

	This is a simple to do list application developed with Html, Css and javascript all included in one file.It allows you to add tasks and cross out the ones you have completed each task.After crossing out all tasks for the day you can clear the list to start a new one.
It uses the event driven architecture which consistes of event producers that generate a stream of events and event consumers that listen for event so that they can perform a set of operations.Each event is linked with an event listener to perform some action.

